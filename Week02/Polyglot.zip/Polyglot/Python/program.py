def main():
    print("This one is easy and I guess you picked it first.")
    print("I will help you by outputing some keywords for the next languages:")
    keywords = ["g++", "mono", "npm"]
    print(" ".join(keywords))

    print("And the answer from here is:")
    print("google")


if __name__ == "__main__":
    main()
