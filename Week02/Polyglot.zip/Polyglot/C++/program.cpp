#include "base64.h"
#include <iostream>

int main() {
  std::string encoded = "aGVhZGVyIGZpbGVz";
  std::string decoded = base64_decode(encoded);

  std::cout << "You got this right!" << std::endl;
  std::cout << "C++ requires you to compile the base64.cpp file as well, in order to have the functions" << std::endl;
  std::cout << "Your answer is:" << std::endl;
  std::cout << decoded << std::endl;

  return 0;
}
